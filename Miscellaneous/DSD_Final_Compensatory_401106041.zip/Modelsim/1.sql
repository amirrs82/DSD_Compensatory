SELECT
    pp,
    ks
FROM
    market
    NATURAL JOIN price
    NATURAL JOIN normal
    NATURAL JOIN transaction;

--q4
SELECT
    price
FROM
    unit
    NATURAL JOIN market
    NATURAL JOIN order_book
    NATURAL JOIN normal_trade
ORDER BY
    price DESC
WHERE
    type = 'buy'
LIMIT
    10
UNION
SELECT
    price
FROM
    unit
    NATURAL JOIN market
    NATURAL JOIN order_book
    NATURAL JOIN normal_trade
ORDER BY
    price
WHERE
    type = 'sell'
LIMIT
    10;

--q5
SELECT
    *
FROM
    unit
    NATURAL JOIN market
    NATURAL JOIN order_book
    NATURAL JOIN normal_trade
ORDER BY
    price
WHERE
    type = 'sell' AND SUM(price * )